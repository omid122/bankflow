# TESTING.md

## چه تست‌هایی نوشته شده است؟

**Unit Tests**
- `tests/test_validation_stage.py` — تمام قوانین مرحله‌ی `VALIDATION`
  (customerId خالی، amount صفر/منفی، فرمت‌های نامعتبر phone، loanType
  نامعتبر، monthlyIncome منفی، creditScore خارج از بازه‌ی [0,1000]) و
  مسیر موفق.
- `tests/test_other_stages.py` — `FraudCheckStage` (customerId با پیشوند
  `FRAUD`/`REVIEW`/عادی)، `GuarantorCheckStage` (وجود/عدم وجود ضامن)،
  `CreditCheckStage` (سه بازه‌ی FAIL/MANUAL_REVIEW/PASS و مرزهای آن‌ها)،
  `ManagerApprovalStage` (رابطه‌ی amount در مقابل monthlyIncome × ضریب).
- `tests/test_workflow_engine.py` — مسیر کامل PERSONAL بدون/با نیاز به
  تأیید مدیر، رد شدن در VALIDATION/FRAUD، توقف در MANUAL_REVIEW، مسیر
  BUSINESS با/بدون ضامن، و **ازسرگیری پردازش از یک current_stage
  ذخیره‌شده** (شبیه‌سازی ری‌استارت وسط Workflow).

**Integration Tests**
- `tests/test_api_integration.py` — کل چرخه‌ی HTTP روی یک SQLite موقت
  (per-test, ایزوله): ایجاد درخواست (201 + وضعیت SUBMITTED)، بدنه‌ی
  ناقص/نامعتبر JSON (400 INVALID_REQUEST)، مسیر کامل تا APPROVED با
  بررسی تاریخچه، رد شدن amount نامعتبر **فقط در زمان پردازش نه ثبت**،
  عدم تکرار تاریخچه هنگام process مجدد یک وام تمام‌شده، 404 برای شناسه‌ی
  ناموجود (هم در GET و هم در process)، رد وام BUSINESS بدون ضامن، و توقف
  در MANUAL_REVIEW با تأیید عدم افزایش تاریخچه در تلاش دوم.

## چه بخش‌هایی Unit Test شده‌اند؟

تمام Stage handlerها (`stages.py`) و کل منطق orchestration در
`engine.py` — یعنی دقیقاً همان بخش‌هایی که قوانین کسب‌وکار و شاخه‌های
شرطی Workflow در آن‌ها قرار دارد.

## چه بخش‌هایی Integration Test شده‌اند؟

مسیر کامل HTTP → Service → Engine → Repository → SQLite، شامل رفتار
واقعی FastAPI (کدهای وضعیت HTTP، فرمت پاسخ خطا) و صحت واقعی نوشتن/خواندن
از دیتابیس (نه mock).

## چه بخش‌هایی به دلیل محدودیت زمان تست نشده‌اند؟

- تست بار/هم‌زمانی واقعی (چند goroutine/thread هم‌زمان روی یک loan) —
  فقط منطقاً از طریق قفل per-loan تضمین شده، تست خودکار stress ندارد.
- رفتار سیستم پس از ری‌استارت *واقعی* کانتینر Docker (فقط با unit test
  «باز کردن مجدد همان فایل SQLite» شبیه‌سازی شده، نه یک تست end-to-end
  که واقعاً کانتینر را متوقف/اجرا کند).
- تست‌های مربوط به فایل پیکربندی نامعتبر/ناقص (`rules.json` خراب) —
  رفتار فعلی صرفاً یک exception در startup است؛ حالت‌های edge-case بیشتر
  پوشش داده نشده.
