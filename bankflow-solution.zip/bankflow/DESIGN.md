# DESIGN.md

## معماری کلی

سیستم به پنج لایه مستقل تقسیم شده که هرکدام یک مسئولیت دارند و فقط از طریق
اینترفیس‌های ساده به هم وصل می‌شوند:

```
API (FastAPI)  →  Service (use-case)  →  Workflow Engine  →  Stage Handlers
                          ↓
                     Repository (SQLite)
```

- **domain/** — موجودیت‌ها (`Loan`)، enumها (`LoanStatus`, `Stage`,
  `StageResult`) و تنظیمات قوانین (`RulesConfig`). هیچ وابستگی‌ای به
  فریم‌ورک یا دیتابیس ندارد.
- **workflow/stages.py** — هر مرحله (`ValidationStage`, `FraudCheckStage`,
  `GuarantorCheckStage`, `CreditCheckStage`, `ManagerApprovalStage`) یک
  کلاس مستقل با یک متد `execute()` است. هیچ مرحله‌ای از وجود مرحله دیگر خبر
  ندارد.
- **workflow/definitions.py** — نگاشت «کدام مراحل، به چه ترتیبی، برای کدام
  نوع وام» را نگه می‌دارد (یک دیکشنری از `List[StageStep]`).
- **workflow/engine.py** — الگوریتم عمومی اجرای مراحل (بدون دانستن منطق
  کسب‌وکار).
- **repository/** — لایه‌ی SQLite. تنها جایی که SQL می‌بیند.
- **services/loan_service.py** — هماهنگ‌کننده‌ی use-caseها؛ قفل هم‌زمانی و
  جلوگیری از پردازش تکراری اینجاست.
- **api/** — Pydantic schemas + FastAPI routes + مدیریت خطا.

## اجزای اصلی سیستم

`Loan` (entity) → `StageHandler` (strategy) → `StageStep` (تعریف اجرا +
شرط اجرا) → `WorkflowEngine` (orchestrator) → `LoanRepository`
(persistence) → `LoanService` (use-case + concurrency) → FastAPI routes.

## نحوه‌ی مدل‌سازی Workflow

هر نوع وام (`PERSONAL` / `BUSINESS`) یک لیست ترتیبی از `StageStep` دارد.
هر `StageStep` شامل: مرحله (enum)، handler آن مرحله، و یک `predicate`
(تابع) که تصمیم می‌گیرد آیا این مرحله اصلاً باید اجرا شود یا خیر (مثلاً
`APPROVAL_MANAGER` فقط وقتی `amount > managerApprovalThreshold` باشد اجرا
می‌شود). این باعث می‌شود شاخه‌های شرطی Workflow (نمودار بخش ۲۱ سند چالش)
بدون `if/else` پراکنده در کد، به‌صورت اعلانی (declarative) بیان شوند.

## نحوه‌ی انتخاب مرحله‌ی بعدی

`engine.py` بعد از هر نتیجه‌ی `PASS`، به کمک `_next_runnable_index` اولین
مرحله‌ی بعدی که `predicate` آن `True` است را پیدا می‌کند (مراحلی که شرط‌شان
برقرار نیست، رد/skip می‌شوند و در تاریخچه ثبت نمی‌شوند). نتیجه‌ی `FAIL` →
بلافاصله `REJECTED`. نتیجه‌ی `MANUAL_REVIEW` → بلافاصله وضعیت
`MANUAL_REVIEW` و توقف پردازش.

## اضافه‌کردن یک Stage جدید

۱) یک کلاس جدید در `stages.py` که `StageHandler` را پیاده‌سازی کند (مثلاً
`AmlCheckStage`).
۲) یک `StageStep` جدید در `definitions.py` و درج آن در لیست مربوط به نوع
وام موردنظر، در جای درست از ترتیب.
هیچ تغییری در `engine.py`، `repository`، `service` یا `api` لازم نیست.
همین موضوع برای تغییر ترتیب مراحل هم صدق می‌کند — فقط ترتیب لیست در
`definitions.py` عوض می‌شود.

## نحوه‌ی خواندن قوانین کسب‌وکار از فایل تنظیمات

`RulesConfig.load()` یک‌بار در startup فایل `rules.json` را می‌خواند و یک
شیء immutable (`RulesConfig`) می‌سازد که به همه‌ی stageهایی که نیاز دارند
(`CreditCheckStage`, `ManagerApprovalStage`, و predicate مرحله‌ی مدیر) از
طریق پارامتر تزریق می‌شود. هیچ عدد ثابتی (magic number) در منطق تصمیم‌گیری
وجود ندارد.

## نحوه‌ی ذخیره اطلاعات

SQLite (کتابخانه‌ی استاندارد `sqlite3`, بدون ORM) با دو جدول: `loans`
(وضعیت فعلی) و `loan_history` (تاریخچه‌ی اجرای هر مرحله، با
`UNIQUE(loan_id, stage)` تا از ثبت تکراری یک مرحله جلوگیری شود). هر تغییر
وضعیت loan + ثبت یک ردیف تاریخچه در یک تراکنش اتمیک ذخیره می‌شود
(`save_step`). این یعنی حتی اگر پردازش وسط راه (بین دو مرحله) قطع شود،
داده‌ی نیمه‌کاره ذخیره نمی‌شود؛ فقط پیشرفت مراحل کامل‌شده.

## جلوگیری از پردازش تکراری

سه لایه‌ی محافظت:
1. سطح Service: اگر وضعیت loan از قبل نهایی باشد (`APPROVED`/`REJECTED`/
   `MANUAL_REVIEW`)، `process_loan` بدون اجرای هیچ مرحله‌ای همان وضعیت را
   برمی‌گرداند.
2. سطح Concurrency: یک قفل جداگانه به‌ازای هر `loan_id` مانع از اجرای
   هم‌زمان دو درخواست `process` برای یک loan می‌شود.
3. سطح Storage: `UNIQUE(loan_id, stage)` در جدول تاریخچه، حتی در بدترین
   حالت (باگ در لایه‌های بالاتر)، از ثبت دوباره‌ی یک مرحله جلوگیری می‌کند.

## اگر سیستم بخواهد CHECK_AML اضافه کند

فقط دو تغییر لازم است (بند «اضافه‌کردن Stage جدید» بالا) — معماری فعلی از
قبل برای همین سناریو طراحی شده و در `definitions.py` به‌عنوان کامنت مستند
شده است.

## سه تصمیم مهم طراحی

1. **جداسازی Stage از Workflow Definition از Engine** — تا افزودن/تغییر
   مرحله یا ترتیب، نیازی به تغییر orchestration logic نداشته باشد.
2. **SQLite بدون ORM** — سادگی، صفر وابستگی خارجی، و کفایت کامل برای
   نیازمندی‌های Persistence این چالش؛ ORM سنگینی بی‌جهت اضافه می‌کرد.
3. **اجرای همزمان Workflow در یک درخواست HTTP** (نه async job/queue) —
   چون طبق مستند، `POST /process` باید تا رسیدن به وضعیت نهایی ادامه یابد؛
   یک صف پیام یا پردازش async پیچیدگی بدون ارزش افزوده برای این scope
   اضافه می‌کرد.

## مهم‌ترین Trade-off

انتخاب قفل per-loan در حافظه (thread lock) به‌جای قفل سطح دیتابیس
(`SELECT ... FOR UPDATE` یا معادل) — ساده‌تر و برای یک instance تک‌پردازشی
کافی است، اما اگر سیستم به چند instance/process مقیاس یابد، باید به قفل
سطح دیتابیس یا یک مکانیزم توزیع‌شده مهاجرت کند.
