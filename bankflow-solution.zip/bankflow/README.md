# BankFlow — Loan Processing System

Backend service that manages the multi-stage workflow banks use to review
loan (tashilat) requests: submission, validation, fraud check, guarantor
check, credit check, and manager approval, ending in `APPROVED`,
`REJECTED`, or `MANUAL_REVIEW`.

## Project structure

```
project/
├── src/
│   ├── domain/        # Entities, enums, business-rules config (no framework deps)
│   ├── workflow/       # Stage handlers + workflow definitions + engine
│   ├── repository/     # SQLite persistence
│   ├── services/       # Application/use-case layer (idempotency, concurrency)
│   ├── api/            # FastAPI schemas, routes, error handling
│   ├── config/rules.json  # Business rules (thresholds), read at startup
│   └── main.py         # App wiring / entrypoint
├── tests/              # Unit + integration tests
├── Dockerfile
├── requirements.txt
├── DESIGN.md
├── ENGINEERING_DECISIONS.md
└── TESTING.md
```

## Main technologies used

- Python 3.11
- FastAPI + Uvicorn (REST API)
- Pydantic (request/response validation)
- SQLite (stdlib `sqlite3`, no ORM) for persistence
- Pytest + httpx (testing)

No external services (no Kafka/RabbitMQ/Redis/Postgres) are required — by
design, per the challenge's optional-technology list.

## Build

```bash
docker build -t bankflow .
```

## Run

```bash
docker run -p 8080:8080 bankflow
```

The service listens on port 8080 and is ready within a few seconds
(well under the 60s requirement). Health check:

```bash
curl http://localhost:8080/health
```

### Configuration

Two environment variables can be set on `docker run` if you want to
override the defaults without rebuilding the image:

- `BANKFLOW_DB_PATH` — path to the SQLite file (default: `data/bankflow.db`
  inside the container).
- `BANKFLOW_RULES_PATH` — path to the business-rules JSON file (default:
  `src/config/rules.json`). Mount a new file at this path (e.g.
  `-v $(pwd)/my-rules.json:/app/custom-rules.json -e BANKFLOW_RULES_PATH=/app/custom-rules.json`)
  to change thresholds without touching source code.

To persist data across `docker run` invocations (not just across
in-container restarts), mount a volume:

```bash
docker run -p 8080:8080 -v $(pwd)/data:/app/data bankflow
```

## Running the tests locally (without Docker)

```bash
pip install -r requirements.txt
pytest -q
```

All tests use a temporary SQLite file per test (via `tmp_path` +
`BANKFLOW_DB_PATH`), so they never touch your real data file and can run
in parallel-safe isolation.

## API summary

| Method | Path                              | Purpose                        |
|--------|-----------------------------------|---------------------------------|
| POST   | `/api/v1/loans`                   | Submit a new loan request       |
| POST   | `/api/v1/loans/{loanId}/process`  | Run the workflow to completion  |
| GET    | `/api/v1/loans/{loanId}`          | Get current loan state          |
| GET    | `/api/v1/loans/{loanId}/history`  | Get stage execution history     |
| GET    | `/health`                         | Health check                    |

See `DESIGN.md` for the workflow model and extensibility notes.
